#!/usr/bin/env bash
set -x ## Print all executed commands to the terminal
set -e ## Exit immediately if a command exits with a non-zero status

cd 1x_orig/
mkdir -p ../1x_white_outline/{terrain,units,buildings,misc}
mkdir -p ../1x_transparent_outline/{terrain,units,buildings,misc}
mkdir -p ../2x_white_outline/{terrain,units,buildings,misc}

for f in units/*.png; do convert $f ../1x_orig/"$f"; done
for f in buildings/*.png; do convert $f ../1x_orig/"$f"; done
for f in terrain/*.png; do convert $f ../1x_orig/"$f"; done

for f in units/*.png; do convert $f -bordercolor none -border 1x1 ../1x_transparent_outline/"$f"; done
for f in buildings/*.png; do convert $f -bordercolor none -border 1x1 ../1x_transparent_outline/"$f"; done
for f in terrain/*.png; do convert $f -bordercolor none -border 1x1 ../1x_transparent_outline/"$f"; done

for f in units/*.png; do convert $f -bordercolor none -border 1x1 \( +clone -channel A -morphology EdgeOut Diamond \) -compose DstOver -composite -fuzz 0% -fill white -opaque black -scale 100% ../1x_white_outline/"$f"; done
for f in buildings/*.png; do convert $f -bordercolor none -border 1x1 \( +clone -channel A -morphology EdgeOut Diamond \) -compose DstOver -composite -fuzz 0% -fill white -opaque black -scale 100% ../1x_white_outline/"$f"; done
for f in terrain/*.png; do convert $f -bordercolor none -border 1x1 \( +clone -channel A -morphology EdgeOut Diamond \) -compose DstOver -composite -fuzz 0% -fill white -opaque black -scale 100% ../1x_white_outline/"$f"; done

for f in units/*.png; do convert $f -bordercolor none -border 1x1 \( +clone -channel A -morphology EdgeOut Diamond \) -compose DstOver -composite -fuzz 0% -fill white -opaque black -scale 200% ../2x_white_outline/"$f"; done
for f in buildings/*.png; do convert $f -bordercolor none -border 1x1 \( +clone -channel A -morphology EdgeOut Diamond \) -compose DstOver -composite -fuzz 0% -fill white -opaque black -scale 200% ../2x_white_outline/"$f"; done
for f in terrain/*.png; do convert $f -bordercolor none -border 1x1 \( +clone -channel A -morphology EdgeOut Diamond \) -compose DstOver -composite -fuzz 0% -fill white -opaque black -scale 200% ../2x_white_outline/"$f"; done

# generate html
# for i in *.png; do echo "<img src=\"$i\" />" >> all.html; done

# html regex
#<img src="([^"]*)" />
#<a href="1x_transparent_outline/\1"><img src="2x_white_outline/\1" /></a>
